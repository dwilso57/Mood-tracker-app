# Mood Tracker & Journal

A comprehensive web-based mood tracking and journaling application built with Streamlit. Track your daily moods, write journal entries, and gain insights into your emotional well-being through detailed analytics and visualizations.

## Features

### 📝 Daily Mood Logging
- Simple mood rating system (1-5 scale with emoji feedback)
- Optional journal entries for detailed reflection
- Update or edit existing entries
- Visual mood indicators and quick stats

### 📊 Analytics & Insights
- Mood trend analysis with moving averages
- Weekly and monthly pattern recognition
- Mood distribution charts and statistics
- Volatility analysis and stability scoring
- Streak tracking and consistency metrics
- Correlation analysis between mood and various factors

### 📅 Calendar View
- Month-by-month mood visualization
- Interactive calendar navigation
- Quick entry editing and addition
- Monthly summary statistics
- Mood heatmap visualization

### 📋 History & Search
- Comprehensive entry browsing with pagination
- Advanced filtering by date range and mood rating
- Full-text search through journal entries
- Detailed entry statistics and insights
- Word frequency analysis for journal content

### 📤 Data Export
- Multiple export formats (CSV, JSON, Analytics Reports, Text Summaries)
- Customizable date ranges and format options
- Complete backup and restore functionality
- Comprehensive analytics reports with insights

## Getting Started

### Prerequisites
- Python 3.11+
- Streamlit
- Pandas
- Plotly

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/mood-tracker-app.git
cd mood-tracker-app
```

2. Install dependencies:
```bash
pip install streamlit pandas plotly
```

3. Run the application:
```bash
streamlit run app.py
```

The application will open in your web browser at `http://localhost:8501`.

## Project Structure

```
mood-tracker-app/
├── app.py                  # Main application dashboard
├── pages/                  # Streamlit multi-page structure
│   ├── 1_📊_Analytics.py   # Analytics and insights page
│   ├── 2_📅_Calendar_View.py # Calendar visualization page
│   ├── 3_📋_History.py     # Entry history and search page
│   └── 4_📤_Export.py      # Data export functionality
├── utils/                  # Utility modules
│   ├── data_manager.py     # Data persistence and management
│   ├── analytics.py        # Mood analytics and calculations
│   └── visualizations.py   # Chart and graph generation
├── .streamlit/
│   └── config.toml         # Streamlit configuration
├── mood_log.csv           # Data storage (created automatically)
└── README.md              # This file
```

## Usage

### Logging Your First Mood
1. Open the application
2. Use the mood slider to rate your current mood (1-5)
3. Optionally write a journal entry about your day
4. Click "Save Entry" to record your mood

### Viewing Analytics
Navigate to the "Analytics" page to see:
- Mood trends over time
- Weekly and monthly patterns
- Statistical insights and correlations
- Volatility analysis and streak tracking

### Browsing History
Use the "History" page to:
- Search through past journal entries
- Filter entries by date or mood rating
- View detailed statistics for filtered data
- Export selected data

### Calendar Navigation
The "Calendar View" allows you to:
- See your moods laid out in calendar format
- Navigate between months
- Click on days to view or edit entries
- Get monthly mood summaries

## Data Storage

The application uses a simple CSV file (`mood_log.csv`) for data persistence. This file contains:
- `date`: Entry date in YYYY-MM-DD format
- `mood`: Mood rating (1-5 integer)
- `journal`: Journal entry text (optional)

## Customization

### Mood Scale
The default 1-5 mood scale can be customized by modifying the mood rating options in the form components.

### Themes and Styling
Streamlit themes can be customized in `.streamlit/config.toml`. The application includes custom CSS for enhanced visual appeal.

### Analytics
Additional analytics can be added by extending the `MoodAnalytics` class in `utils/analytics.py`.

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/new-feature`)
3. Commit your changes (`git commit -am 'Add new feature'`)
4. Push to the branch (`git push origin feature/new-feature`)
5. Create a Pull Request

## License

This project is open source and available under the [MIT License](LICENSE).

## Acknowledgments

- Built with [Streamlit](https://streamlit.io/) for the web framework
- [Plotly](https://plotly.com/) for interactive visualizations
- [Pandas](https://pandas.pydata.org/) for data management

## Support

If you encounter any issues or have suggestions for improvements, please create an issue in the GitHub repository.

---

*Start your mood tracking journey today and gain valuable insights into your emotional well-being!*